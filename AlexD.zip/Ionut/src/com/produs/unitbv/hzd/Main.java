package com.produs.unitbv.hzd;

import model.CityModel;
import model.CommerceZoneModel;
import model.ParkingZoneModel;

/**
 * Main Class
 *
 * @author ionuthzd@gmail.com
 */
public class Main {

    private static final String COORDONATE_ORAS_PATH  = "";
    private static final String COMERCIAL_PATH = "C:\\Users\\alexd\\Downloads\\comercial.json";
    private static final String PARCARI_PATH = "C:\\Users\\alexd\\Downloads\\parcari.json";

    private static CityModel getCityModel() {
        JsonWrapper jsonWrapper = new JsonWrapper();
        return (CityModel) jsonWrapper.deserialize(COORDONATE_ORAS_PATH, CityModel.class);
    }

    private static CommerceZoneModel getCommerceZone() {
        JsonWrapper jsonWrapper = new JsonWrapper();
        return (CommerceZoneModel) jsonWrapper.deserialize(COMERCIAL_PATH, CommerceZoneModel.class);
    }

    private static ParkingZoneModel getParkingZone() {
        JsonWrapper jsonWrapper = new JsonWrapper();
        return (ParkingZoneModel) jsonWrapper.deserialize(PARCARI_PATH, ParkingZoneModel.class);
    }

    public static void main(String[] args) {
        CityModel city = getCityModel();
        CommerceZoneModel commerceZone = getCommerceZone();
        ParkingZoneModel parkingZone = getParkingZone();
    }
}
