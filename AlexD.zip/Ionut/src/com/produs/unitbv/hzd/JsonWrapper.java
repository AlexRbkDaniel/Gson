package com.produs.unitbv.hzd;

import com.google.gson.Gson;
import model.GeoSpaceModel;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

/** JsonWrapper
 * @author ionuthzd@gmail.com
 */
public class JsonWrapper {

    public <T> GeoSpaceModel deserialize(String filePath, final Class<T> resultClass) {
        Gson gson = new Gson();
        try  {
            Reader reader = new FileReader(filePath);
            T object = gson.fromJson(reader, resultClass);
            reader.close();
            return (GeoSpaceModel) object;
        } catch (IOException error) {
            System.out.println("Eroare Citire Fisier");
        }
        return null;
    }

}
