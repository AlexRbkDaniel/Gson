package model.enums;

public enum SHOP_CATEGORY {
    PHARMA
}
