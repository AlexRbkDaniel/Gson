package model;

import java.io.Serializable;
import java.util.List;

/**
 * ParkingZoneModel
 *
 * @author ionuthzd@gmail.com
 */
public class ParkingZoneModel extends GeoSpaceModel implements Serializable {

    private Double pricePerHour;
    private List<ParkingSpaceModel> parcari;

    public ParkingZoneModel() {
    }

    public ParkingZoneModel(String name, GeographicCoordinatesModel geographicCoordinates, Double pricePerHour, List<ParkingSpaceModel> parkingSpaces) {
        super.setNume(name);
        this.pricePerHour = pricePerHour;
        this.parcari = parkingSpaces;
    }

    public Double getPricePerHour() {
        return pricePerHour;
    }

    public void setPricePerHour(Double pricePerHour) {
        this.pricePerHour = pricePerHour;
    }

    public List<ParkingSpaceModel> getParcari() {
        return parcari;
    }

    public void setParcari(List<ParkingSpaceModel> parcari) {
        this.parcari = parcari;
    }
}
