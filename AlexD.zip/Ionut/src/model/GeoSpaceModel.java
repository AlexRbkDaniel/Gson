package model;

public class GeoSpaceModel {

    private String nume;
    private Integer N;
    private Integer S;
    private Integer V;
    private Integer E;

    public GeoSpaceModel() {
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public Integer getN() {
        return N;
    }

    public void setN(Integer n) {
        N = n;
    }

    public Integer getS() {
        return S;
    }

    public void setS(Integer s) {
        S = s;
    }

    public Integer getV() {
        return V;
    }

    public void setV(Integer v) {
        V = v;
    }

    public Integer getE() {
        return E;
    }

    public void setE(Integer e) {
        E = e;
    }
}
