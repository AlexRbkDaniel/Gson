package model;

import java.io.Serializable;

/**
 * GeographicCoordinatesModel
 *
 * @author ionuthzd@gmail.com
 */
public class GeographicCoordinatesModel implements Serializable {

    private String name;
    private Integer latN;
    private Integer latS;
    private Integer longW;
    private Integer longE;

    public GeographicCoordinatesModel() {
    }

    public GeographicCoordinatesModel(String name, Integer latN, Integer latS, Integer longW, Integer longE) {
        this.name = name;
        this.latN = latN;
        this.latS = latS;
        this.longW = longW;
        this.longE = longE;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getLatN() {
        return latN;
    }

    public void setLatN(Integer latN) {
        this.latN = latN;
    }

    public Integer getLatS() {
        return latS;
    }

    public void setLatS(Integer latS) {
        this.latS = latS;
    }

    public Integer getLongW() {
        return longW;
    }

    public void setLongW(Integer longW) {
        this.longW = longW;
    }

    public Integer getLongE() {
        return longE;
    }

    public void setLongE(Integer longE) {
        this.longE = longE;
    }
}
