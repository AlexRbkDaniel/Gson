package model;

import java.io.Serializable;

public class ParkingSpaceModel extends GeoSpaceModel implements Serializable {

    private String locuri;

    public ParkingSpaceModel() {
    }

    public ParkingSpaceModel(String name, String parkingSpacesNumber, GeographicCoordinatesModel geographicCoordinates) {
        super.setNume(name);
        this.locuri = parkingSpacesNumber;
    }

    public String getLocuri() {
        return locuri;
    }

    public void setLocuri(String locuri) {
        this.locuri = locuri;
    }
}
