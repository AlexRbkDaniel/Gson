package model;

import java.io.Serializable;
import java.util.List;

/**
 * City Model
 *
 * @author ionuthzd@gmail.com
 */
public class CityModel extends GeoSpaceModel implements Serializable {

    private List<CommerceZoneModel> commerceZones;

    public CityModel() {
    }

    public CityModel(String name, GeographicCoordinatesModel geographicCoordinates, List<CommerceZoneModel> commerceZones) {
        super.setNume(name);
        this.commerceZones = commerceZones;
    }

    public List<CommerceZoneModel> getCommerceZones() {
        return commerceZones;
    }

    public void setCommerceZones(List<CommerceZoneModel> commerceZones) {
        this.commerceZones = commerceZones;
    }

}
