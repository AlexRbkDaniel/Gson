package model;

import java.io.Serializable;
import java.util.List;

public class CommerceZoneModel extends GeoSpaceModel implements Serializable {

    private List<ShopModel> magazine;

    public CommerceZoneModel() {

    }

    public CommerceZoneModel(String name, List<ShopModel> shops) {
        super.setNume(name);
        this.magazine = shops;
    }

    public List<ShopModel> getMagazine() {
        return magazine;
    }

    public void setMagazine(List<ShopModel> magazine) {
        this.magazine = magazine;
    }
}
