package model;

import model.enums.SHOP_CATEGORY;

import java.io.Serializable;

/**
 * ShopModel
 *
 * @author ionuthzd@gmail.com
 */
public class ShopModel extends GeoSpaceModel implements Serializable {

    private String tip;

    public ShopModel() {
    }

    public ShopModel(String name, String category, GeographicCoordinatesModel geographicCoordinates) {
        super.setNume(name);
        this.tip = category;
    }

    public String getTip() {
        return tip;
    }

    public void setTip(String tip) {
        this.tip = tip;
    }
}
